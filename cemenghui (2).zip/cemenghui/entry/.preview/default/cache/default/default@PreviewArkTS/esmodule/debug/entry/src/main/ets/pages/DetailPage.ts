if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DetailPage_Params {
    logoIndex?: number;
    descriptionText?: string;
}
import router from "@ohos:router";
import util from "@ohos:util";
interface GeneratedTypeLiteralInterface_1 {
    logoIndex?: number;
}
interface MemberItem {
    name: string;
    value: string;
}
interface MemberJson {
    string: MemberItem[];
}
export class DetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__logoIndex = new ObservedPropertySimplePU(0, this, "logoIndex");
        this.__descriptionText = new ObservedPropertySimplePU('加载中...', this, "descriptionText");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DetailPage_Params) {
        if (params.logoIndex !== undefined) {
            this.logoIndex = params.logoIndex;
        }
        if (params.descriptionText !== undefined) {
            this.descriptionText = params.descriptionText;
        }
    }
    updateStateVars(params: DetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__logoIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__descriptionText.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__logoIndex.aboutToBeDeleted();
        this.__descriptionText.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __logoIndex: ObservedPropertySimplePU<number>;
    get logoIndex() {
        return this.__logoIndex.get();
    }
    set logoIndex(newValue: number) {
        this.__logoIndex.set(newValue);
    }
    private __descriptionText: ObservedPropertySimplePU<string>;
    get descriptionText() {
        return this.__descriptionText.get();
    }
    set descriptionText(newValue: string) {
        this.__descriptionText.set(newValue);
    }
    aboutToAppear() {
        const params = router.getParams() as GeneratedTypeLiteralInterface_1;
        if (params?.logoIndex !== undefined) {
            this.logoIndex = Number(params.logoIndex);
        }
        this.loadJsonDescription(this.logoIndex);
    }
    private async loadJsonDescription(index: number) {
        try {
            const context = getContext(this);
            const fileData: Uint8Array = await context.resourceManager.getRawFile('member_descriptions.json');
            // 使用 HarmonyOS 提供的 TextDecoder
            const decoder = new util.TextDecoder('utf-8');
            const jsonStr = decoder.decode(fileData);
            const jsonData: MemberJson = JSON.parse(jsonStr);
            const descriptionArray = jsonData.string;
            if (Array.isArray(descriptionArray) && index >= 0 && index < descriptionArray.length) {
                this.descriptionText = descriptionArray[index].value;
            }
            else {
                this.descriptionText = '暂无信息';
            }
        }
        catch (err) {
            console.error('读取 JSON 出错：', JSON.stringify(err));
            this.descriptionText = '加载失败';
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DetailPage.ets(58:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.descriptionText);
            Text.debugLine("entry/src/main/ets/pages/DetailPage.ets(59:7)", "entry");
            Text.fontSize(18);
            Text.fontColor(Color.Black);
            Text.padding(16);
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DetailPage";
    }
}
registerNamedRoute(() => new DetailPage(undefined, {}), "", { bundleName: "com.example.cemenghui", moduleName: "entry", pagePath: "pages/DetailPage", pageFullPath: "entry/src/main/ets/pages/DetailPage", integratedHsp: "false", moduleType: "followWithHap" });
