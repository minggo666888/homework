if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CooperationContent_Params {
    cardData?: Array<TabItem1>;
}
import type { TabItem1 } from "../model/Types";
export class CooperationContent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.cardData = [
            { id: 1, Img: { "id": 16777262, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" } },
            { id: 2, Img: { "id": 16777261, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" } },
            { id: 3, Img: { "id": 16777249, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" } },
            { id: 4, Img: { "id": 16777264, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" } },
            { id: 5, Img: { "id": 16777263, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" } } // 公益行动
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CooperationContent_Params) {
        if (params.cardData !== undefined) {
            this.cardData = params.cardData;
        }
    }
    updateStateVars(params: CooperationContent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private cardData: Array<TabItem1>;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/CooperationContent.ets(14:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 1. 顶部标题栏（保持原样）
            Row.create();
            Row.debugLine("entry/src/main/ets/view/CooperationContent.ets(16:7)", "entry");
            // 1. 顶部标题栏（保持原样）
            Row.width('100%');
            // 1. 顶部标题栏（保持原样）
            Row.height(56);
            // 1. 顶部标题栏（保持原样）
            Row.justifyContent(FlexAlign.Center);
            // 1. 顶部标题栏（保持原样）
            Row.linearGradient({
                angle: 90,
                colors: [[0x7D5FFF, 0], [0x9050FF, 1]]
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('合作');
            Text.debugLine("entry/src/main/ets/view/CooperationContent.ets(17:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.White);
            Text.margin({ top: 12 });
        }, Text);
        Text.pop();
        // 1. 顶部标题栏（保持原样）
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/view/CooperationContent.ets(31:7)", "entry");
            Blank.height('3%');
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 2. 使用List组件重构卡片区域（关键改进）
            List.create({ space: 12 });
            List.debugLine("entry/src/main/ets/view/CooperationContent.ets(34:7)", "entry");
            // 2. 使用List组件重构卡片区域（关键改进）
            List.width('95%');
            // 2. 使用List组件重构卡片区域（关键改进）
            List.lanes(2);
            // 2. 使用List组件重构卡片区域（关键改进）
            List.flexGrow(1);
            // 2. 使用List组件重构卡片区域（关键改进）
            List.backgroundColor('#F5F5F5');
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.margin({ left: '5vp', right: '5vp' });
                        ListItem.debugLine("entry/src/main/ets/view/CooperationContent.ets(36:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/view/CooperationContent.ets(37:13)", "entry");
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            // 特殊处理公益行动卡片（单行显示）
                            if (item.id === 5) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Image.create(item.Img);
                                        Image.debugLine("entry/src/main/ets/view/CooperationContent.ets(40:17)", "entry");
                                        Image.width('100%');
                                        Image.aspectRatio(0.9);
                                        Image.objectFit(ImageFit.Contain);
                                    }, Image);
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 普通双列卡片
                                        Image.create(item.Img);
                                        Image.debugLine("entry/src/main/ets/view/CooperationContent.ets(46:17)", "entry");
                                        // 普通双列卡片
                                        Image.width('100%');
                                        // 普通双列卡片
                                        Image.aspectRatio(0.9);
                                        // 普通双列卡片
                                        Image.objectFit(ImageFit.Contain);
                                    }, Image);
                                });
                            }
                        }, If);
                        If.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.cardData, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 2. 使用List组件重构卡片区域（关键改进）
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
