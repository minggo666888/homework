if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MainPage_Params {
    currentIndex?: number;
    tabItems?: Array<TabItem>;
}
import { HomeContent } from "@normalized:N&&&entry/src/main/ets/view/HomeContent&";
import { NewsContent } from "@normalized:N&&&entry/src/main/ets/view/NewsContent&";
import { TechContent } from "@normalized:N&&&entry/src/main/ets/view/TechContent&";
import { CooperationContent } from "@normalized:N&&&entry/src/main/ets/view/CooperationContent&";
import type { TabItem } from '../model/Types';
class MainPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.tabItems = [
            {
                title: '首页',
                iconSelected: { "id": 16777226, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
                iconNormal: { "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" }
            },
            {
                title: '动态',
                iconSelected: { "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
                iconNormal: { "id": 16777220, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" }
            },
            {
                title: '技术',
                iconSelected: { "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
                iconNormal: { "id": 16777221, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" }
            },
            {
                title: '合作',
                iconSelected: { "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
                iconNormal: { "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" }
            }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MainPage_Params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.tabItems !== undefined) {
            this.tabItems = params.tabItems;
        }
    }
    updateStateVars(params: MainPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentIndex: ObservedPropertySimplePU<number>; // 当前选中索引
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    // 底部导航配置
    private tabItems: Array<TabItem>;
    // 构建底部导航项
    TabItemBuilder(item: TabItem, index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(39:5)", "entry");
            Column.width('25%');
            Column.height(56);
            Column.justifyContent(FlexAlign.Center);
            Column.onClick(() => {
                this.currentIndex = index; // 点击切换当前选中项
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.currentIndex === index ? item.iconSelected : item.iconNormal);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(40:7)", "entry");
            Image.width(24);
            Image.height(24);
            Image.margin({ bottom: 4 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(45:7)", "entry");
            Text.fontSize(12);
            Text.fontColor(this.currentIndex === index ? '#007AFF' : '#999999');
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(58:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Index.ets(59:7)", "entry");
            Scroll.layoutWeight(1);
            Scroll.scrollBar(BarState.Auto);
            Scroll.scrollBarColor('#888888');
            Scroll.scrollBarWidth(6);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(60:9)", "entry");
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.currentIndex === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new HomeContent(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 62, col: 13 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {};
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "HomeContent" });
                    }
                });
            }
            else if (this.currentIndex === 1) {
                this.ifElseBranchUpdateFunction(1, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new NewsContent(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 64, col: 13 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {};
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "NewsContent" });
                    }
                });
            }
            else if (this.currentIndex === 2) {
                this.ifElseBranchUpdateFunction(2, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new TechContent(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 66, col: 13 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {};
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "TechContent" });
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            if (isInitialRender) {
                                let componentCall = new CooperationContent(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 68, col: 13 });
                                ViewPU.create(componentCall);
                                let paramsLambda = () => {
                                    return {};
                                };
                                componentCall.paramsGenerator_ = paramsLambda;
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                        }, { name: "CooperationContent" });
                    }
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(70:11)", "entry");
            Blank.height(30);
        }, Blank);
        Blank.pop();
        Column.pop();
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 底部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(81:7)", "entry");
            // 底部导航栏
            Row.width('100%');
            // 底部导航栏
            Row.height(56);
            // 底部导航栏
            Row.backgroundColor('#FFFFFF');
            // 底部导航栏
            Row.border({ width: 1, color: '#F0F0F0' });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.TabItemBuilder.bind(this)(item, index);
            };
            this.forEachUpdateFunction(elmtId, this.tabItems, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // 底部导航栏
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MainPage";
    }
}
registerNamedRoute(() => new MainPage(undefined, {}), "", { bundleName: "com.example.cemenghui", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
