if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface HomeContent_Params {
    currentBannerIndex?: number;
    bannerImages?;
    memberLogos?;
}
import router from "@ohos:router";
export class HomeContent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentBannerIndex = new ObservedPropertySimplePU(0, this, "currentBannerIndex");
        this.bannerImages = [
            { "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
        ];
        this.memberLogos = [
            { "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777245, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777243, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777246, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777241, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777247, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777244, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" },
            { "id": 16777242, "type": 20000, params: [], "bundleName": "com.example.cemenghui", "moduleName": "entry" }
        ];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: HomeContent_Params) {
        if (params.currentBannerIndex !== undefined) {
            this.currentBannerIndex = params.currentBannerIndex;
        }
        if (params.bannerImages !== undefined) {
            this.bannerImages = params.bannerImages;
        }
        if (params.memberLogos !== undefined) {
            this.memberLogos = params.memberLogos;
        }
    }
    updateStateVars(params: HomeContent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentBannerIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentBannerIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentBannerIndex: ObservedPropertySimplePU<number>;
    get currentBannerIndex() {
        return this.__currentBannerIndex.get();
    }
    set currentBannerIndex(newValue: number) {
        this.__currentBannerIndex.set(newValue);
    }
    private bannerImages;
    private memberLogos;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/view/HomeContent.ets(25:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#DCDCDC');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 轮播图区域（您说直接截图，这里保留基本结构）
            Swiper.create();
            Swiper.debugLine("entry/src/main/ets/view/HomeContent.ets(27:9)", "entry");
            // 轮播图区域（您说直接截图，这里保留基本结构）
            Swiper.indicator(true);
            // 轮播图区域（您说直接截图，这里保留基本结构）
            Swiper.autoPlay(true);
            // 轮播图区域（您说直接截图，这里保留基本结构）
            Swiper.width('95%');
            // 轮播图区域（您说直接截图，这里保留基本结构）
            Swiper.height(180);
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const image = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(image);
                    Image.debugLine("entry/src/main/ets/view/HomeContent.ets(29:13)", "entry");
                    Image.width('100%');
                    Image.height(180);
                    Image.borderRadius(16);
                }, Image);
            };
            this.forEachUpdateFunction(elmtId, this.bannerImages, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 轮播图区域（您说直接截图，这里保留基本结构）
        Swiper.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/view/HomeContent.ets(40:9)", "entry");
            Blank.height('3%');
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 精确还原图片中的文字内容
            Column.create();
            Column.debugLine("entry/src/main/ets/view/HomeContent.ets(44:9)", "entry");
            // 精确还原图片中的文字内容
            Column.width('100%');
            // 精确还原图片中的文字内容
            Column.padding(16);
            // 精确还原图片中的文字内容
            Column.backgroundColor('#FFFFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('中国电子质量管理协会');
            Text.debugLine("entry/src/main/ets/view/HomeContent.ets(45:11)", "entry");
            Text.fontSize(20);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('计算机软硬件和信息系统质量测评分会');
            Text.debugLine("entry/src/main/ets/view/HomeContent.ets(51:11)", "entry");
            Text.fontSize(18);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('计算机软硬件和信息系统质量测评分会是中国电子质量管理协会设立的17个分支机构之一。分会可以对计算机软硬件和信息系统所有潜在的、现有的风险进行评估及分析并对自愿申请参加能力评审的造价评估机构进行客观、公正的能力评审，最终给出能力评审结论。');
            Text.debugLine("entry/src/main/ets/view/HomeContent.ets(57:11)", "entry");
            Text.fontSize(16);
            Text.fontColor('#000000');
            Text.lineHeight(24);
        }, Text);
        Text.pop();
        // 精确还原图片中的文字内容
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Blank()
            //   .height('3%')
            Grid.create();
            Grid.debugLine("entry/src/main/ets/view/HomeContent.ets(69:9)", "entry");
            // Blank()
            //   .height('3%')
            Grid.columnsTemplate('1fr 1fr 1fr 1fr');
            // Blank()
            //   .height('3%')
            Grid.rowsTemplate('1fr 1fr 1fr');
            // Blank()
            //   .height('3%')
            Grid.columnsGap(0);
            // Blank()
            //   .height('3%')
            Grid.rowsGap(0);
            // Blank()
            //   .height('3%')
            Grid.width('100%');
            // Blank()
            //   .height('3%')
            Grid.aspectRatio(4 / 3);
            // Blank()
            //   .height('3%')
            Grid.margin({ top: 16 });
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const logo = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("entry/src/main/ets/view/HomeContent.ets(71:13)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(logo);
                            Image.debugLine("entry/src/main/ets/view/HomeContent.ets(72:15)", "entry");
                            Image.width(60);
                            Image.height(60);
                            Image.objectFit(ImageFit.Cover);
                            Image.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/DetailPage',
                                    params: {
                                        logoIndex: index
                                    }
                                });
                            });
                        }, Image);
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.memberLogos, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        // Blank()
        //   .height('3%')
        Grid.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
